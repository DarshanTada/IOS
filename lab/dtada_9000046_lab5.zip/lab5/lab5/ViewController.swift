//
//  ViewController.swift
//  lab5
//
//  Created by Admin on 2024-06-22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

